package Entregable1PSP;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class main {
	

	public static void main(String[] args) {
	
	Scanner teclado = new Scanner(System.in);

	int n1 = 0;
	int n2 = 0;
		
		
	System.out.println("1: Hola Mundo");	
	System.out.println("2: Numeros");
	System.out.println("3: Nombres compañeros");
		
	switch (teclado.nextInt()) {
	case 1:
		App.sayHello();
		break;
	case 2:
		System.out.println("Dime el numero1: ");
		n1 = teclado.nextInt();
		System.out.println("Dime el numero2: ");
		n2 = teclado.nextInt();
		break;
	case 3: 
		nombres();
	default:
		break;
	}

		
	}

	public static void numeros() {
		
		
		
		
		
		
		
		
	}


	public static void nombres() {

		Array [] nombre = new Array[6];
		
		int cont =0;
		
		nombre[0] = "Fermin";
		nombre[1] = "Xavier";
		nombre[2] = "Pablo";
		nombre[3] = "Andry";
		nombre[4] = "Alberto";
		nombre[5] = "Gonzalo";
	
		
		for (Array array : nombre) {
			System.out.println(cont);	
			cont++;
		}
		
	}
	
	
	
	
		
	

}
