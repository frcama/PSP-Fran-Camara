package Entregable1PSP;

public class App {
	
	public static void sayHello () {
		System.out.println("Hola Mundo");
		return;
	}
}
