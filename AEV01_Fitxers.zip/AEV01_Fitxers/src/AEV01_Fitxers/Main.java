package AEV01_Fitxers;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		
		String ruta;
		String rutacarpeta;
		String rutafichero;
		String eliminar;
		
        System.out.println("Selecciona una operación:");
        System.out.println("1. Mostrar información");
        System.out.println("2. Crear carpeta");
        System.out.println("3. Crear fichero");
        System.out.println("4. Eliminar fichero o carpeta");
        System.out.println("5. Renombrar fichero o carpeta");
        
        int opcion = teclado.nextInt();
        teclado.nextLine(); 

        switch (opcion) {
            case 1:
                System.out.print("Introduce la ruta: ");
                ruta = teclado.nextLine();
                File fitxer = new File(ruta);
                System.out.println(getInformacion(fitxer));
                break;

            case 2:
                System.out.print("Introduce la ruta para crear la carpeta: ");
                rutacarpeta = teclado.nextLine();
                break;

            case 3:
                System.out.print("Introduce la ruta on crear el fitxer: ");
                rutafichero = teclado.nextLine();
                break;

            case 4:
                System.out.print("Introduce la ruta del fichero o carpeta a eliminar: ");
                eliminar = teclado.nextLine();
                
                break;

            case 5:
                break;

            default:
                System.out.println("Opcion no valida.");
        }

      
    }
	 public static String getInformacion(File fitxer) {
	        StringBuilder info = new StringBuilder();
	        
	        if (!fitxer.exists()) {
	            return "Error: El fichero o directorio no existe.";
	        }

	        if (!fitxer.canRead()) {
	            return "Error: No tienes permisos.";
	        }

	        info.append("Nombre: ").append(fitxer.getName()).append("\n");
	        info.append("Ubicacion: ").append(fitxer.getAbsolutePath()).append("\n");
	        info.append("Última modificacion: ").append(new java.util.Date(fitxer.lastModified())).append("\n");
	        info.append("Oculto: ").append(fitxer.isHidden() ? "Sí" : "No").append("\n");

	        if (fitxer.isFile()) {
	            info.append("Tipos: Fichero\n");
	            info.append("Grandària: ").append(fitxer.length()).append(" bytes\n");
	        } else if (fitxer.isDirectory()) {
	            String[] elements = fitxer.list();
	            if (elements != null) {
	                info.append("Tipo: Directoro\n");
	                info.append("Elementos: ").append(elements.length).append("\n");
	            } else {
	                info.append("Elementos: Error");
	            }
	            info.append("Espacio libre: ").append(fitxer.getFreeSpace()).append(" bytes\n");
	            info.append("Espacio disponible: ").append(fitxer.getUsableSpace()).append(" bytes\n");
	            info.append("Espacio total: ").append(fitxer.getTotalSpace()).append(" bytes\n");
	        }

	        return info.toString();
	    }
	    

		
		
	


}
	

