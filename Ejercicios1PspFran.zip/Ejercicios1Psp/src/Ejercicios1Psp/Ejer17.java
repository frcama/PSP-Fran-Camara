package Ejercicios1Psp;

public class Ejer17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
