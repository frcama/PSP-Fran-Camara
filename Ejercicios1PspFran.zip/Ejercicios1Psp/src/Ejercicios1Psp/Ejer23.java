package Ejercicios1Psp;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejer23 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		
		ArrayList<String> nombres = new ArrayList<>();
		
		for (int i = 0; i < 5; i++) {
            System.out.print("Introduce el nombre de la persona " + (i + 1) + ": ");
            String nombre = teclado.nextLine();
            if (nombre.equals("0")) {
                break;
            }
            nombres.add(nombre); 
		}
		
		System.out.println("Los nombres introducidos son:");
        for (int i = 0; i < nombres.size(); i++) {
            System.out.println((i + 1) + ". " + nombres.get(i));
        }
		
	}

}
