package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer16 {

	public static void main(String[] args) {
		
	Scanner teclado = new Scanner(System.in);
		
	int dia;
	int mes;
	int ano;
	int numsuerte;
	
	System.out.println("Dime el dia de tu naciemiento");
	dia = teclado.nextInt();
	System.out.println("Dime el mes de tu naciemiento");
	mes = teclado.nextInt();
	System.out.println("Dime el ano de tu naciemiento");
	ano = teclado.nextInt();
	
	numsuerte = dia + mes + ano /12;
	
	System.out.println("Este el numero de la surte: "+ numsuerte);
	
	
	
	}

}
