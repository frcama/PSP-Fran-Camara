package Ejercicios1Psp;

public class mian {

	public static void main(String[] args) {
		int n1 = 50;
	    int n2 = 60;
	    int suma = 0;
	    
	    suma = n1+n2;
	    
	    System.out.println("la suma es de :" + suma);

	}

}
