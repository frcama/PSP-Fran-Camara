package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer7 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

        int suma = 0;
        int numero;

        for (int i = 1; i <= 5; i++) {
            System.out.print("Introduce el número " + i + ": ");
             numero = scanner.nextInt();
            
            suma = numero +suma;
        }

      
        System.out.println("La suma de los 5 números es: " + suma);
		
		
	}

}
