package Ejercicios1Psp;

import java.util.Random;
import java.util.Scanner;

public class Ejer25 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

        int[] numerosUsuario = new int[3];
        int[] numerosAleatorios = new int[3];
        
        System.out.println("Por favor, introduce 3 números entre 1 y 10:");

        for (int i = 0; i < 3; i++) {
            System.out.print("Introduce el número " + (i + 1) + ": ");
            numerosUsuario[i] = teclado.nextInt();

            if (numerosUsuario[i] < 1 || numerosUsuario[i] > 10) {
                System.out.println("El número introducido debe estar entre 1 y 10.");
                teclado.close();
                return;
            }
        }

        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            numerosAleatorios[i] = random.nextInt(10) + 1;
        }

        System.out.println("\nNúmeros introducidos: ");
        for (int i = 0; i < 3; i++) {
            System.out.println("Número " + (i + 1) + ": " + numerosUsuario[i]);
        }

        System.out.println("\nNúmeros aleatorios generados: ");
        for (int i = 0; i < 3; i++) {
            System.out.println("Número " + (i + 1) + ": " + numerosAleatorios[i]);
        }

        boolean haGanado = false;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (numerosUsuario[i] == numerosAleatorios[j]) {
                    haGanado = true;
                    break; 
            }
        }

        if (haGanado) {
            System.out.println("Felicidades Has ganado un premio");
            System.out.println("Una cena de gala con una cigala");
        } else {
            System.out.println("números no coincide");
        }
		
		
	}
	}
}


