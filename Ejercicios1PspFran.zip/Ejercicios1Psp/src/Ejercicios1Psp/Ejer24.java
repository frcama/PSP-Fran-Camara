package Ejercicios1Psp;

import java.util.Random;
import java.util.Scanner;

public class Ejer24 {

	public static void main(String[] args) {
		
		Scanner teclado =  new Scanner (System.in);
		
		int numeroAleatorio;
		int numeroUsuario;
		
		
		
        System.out.println("Por favor, introduce un número como parámetro entre 1 y 10.");
        numeroUsuario = teclado.nextInt();

       

        if (numeroUsuario < 1 || numeroUsuario > 10) {
            System.out.println("El número introducido debe estar entre 1 y 10.");
            return;
        }

        Random random = new Random();
         numeroAleatorio = random.nextInt(10) + 1;

        System.out.println("Número introducido: " + numeroUsuario);
        System.out.println("Número aleatorio generado: " + numeroAleatorio);

        if (numeroUsuario == numeroAleatorio) {
            System.out.println("Felicidades Has ganado un premio");
            System.out.println("Cena con pablo pero es una cena celiaca");
        } else {
            System.out.println("los números no coinciden");
        }	
	}

}
