package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer4 {

	public static void main(String[] args) {
			
		Scanner teclado = new Scanner(System.in);

		
		int n1 = 0;
		int n2 = 0;
		
		System.out.println("Dime el numero 1");
		n1 = teclado.nextInt();
		
		System.out.println("Dime el numero 2");
		n2 = teclado.nextInt();
		
		if(n1 > n2) {
			System.out.print("EL n2 es menor que el n1");
		}else if(n2 > n1) {
			System.out.print("EL n2 es mayor que el n1");
		}else {
			System.out.print("Son iguales");
		}
	}

}
