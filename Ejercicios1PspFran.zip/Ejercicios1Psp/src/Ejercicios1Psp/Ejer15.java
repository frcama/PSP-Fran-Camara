package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer15 {

	public static void main(String[] args) {
		
	Scanner teclado = new Scanner (System.in);
		
	double radio =0;
	double diametro;
	double aerea;
	double volumen;
	
	
	System.out.println("Dime el radio");
	radio = teclado.nextDouble();
	
	diametro = 2* radio;
	aerea = Math.PI * (radio/2);
	volumen = (4/3) * Math.PI * (radio/3);
	
	
	System.out.println("El diametro es: " + diametro);
	System.out.println("El aerea es: " + aerea);	
	System.out.println("El volumen es: "+ volumen);
		
		
		
	}

}
