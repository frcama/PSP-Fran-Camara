package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

	    String nombre;

	    System.out.println("Dime tu nombre");
	    nombre = teclado.nextLine();
	    
	    System.out.println("HOla: " + nombre);
	}

}
