package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer26 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

        int suspensos = 0;
        int aprobados = 0;
        int notables = 0;
        int sobresalientes = 0;
        int matriculas = 0;
        double nota;

        for (int i = 1; i <= 10; i++) {
            System.out.print("Introduce la nota " + i + " (0-10): ");
             nota = teclado.nextDouble();

            if (nota >= 0 && nota < 5) {
                suspensos++;
            } else if (nota >= 5 && nota < 7) {
                aprobados++;
            } else if (nota >= 7 && nota < 9) {
                notables++;
            } else if (nota >= 9 && nota < 10) {
                sobresalientes++;
            } else if (nota == 10) {
                matriculas++;
            } else {
                System.out.println("Nota no válida. Debe estar entre 0 y 10.");
                i--; 
            }
        }

        System.out.println("\nResultados:");
        System.out.println("Suspensos: " + suspensos);
        System.out.println("Aprobados: " + aprobados);
        System.out.println("Notables: " + notables);
        System.out.println("Sobresalientes: " + sobresalientes);
        System.out.println("Matrículas de honor: " + matriculas);
	}
	}


