package Ejercicios1Psp;

public class Ejer30 {

	public static void main(String[] args) {

	}

}
