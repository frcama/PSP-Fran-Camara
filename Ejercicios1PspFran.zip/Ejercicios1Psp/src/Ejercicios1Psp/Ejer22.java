package Ejercicios1Psp;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejer22 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		
		ArrayList<String> nombres = new ArrayList<>();
		
		for (int i = 0; i < 5; i++) {
            System.out.print("Introduce el nombre de la persona y el 0 para finalizards " + (i + 1) + ": ");
            String nombre = teclado.nextLine();
            if (nombre.equals("0")) {
                break;
            }
            nombres.add(nombre); 
		}
		
		System.out.println("Los nombres introducidos son:");
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
		
		
	}

}
