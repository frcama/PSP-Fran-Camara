package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer13 {

	public static void main(String[] args) {
	
		
	Scanner teclado = new Scanner(System.in);	
		
	int centigrados = 0;
	int fare;
		
	System.out.println("Dime los centigrados a ingresar ");	
	centigrados = teclado.nextInt();
	
	fare = (centigrados * 9 / 5) + 32;
	
	
	System.out.println("Esta es la conversion: "+ fare);
	
		
	}

}
