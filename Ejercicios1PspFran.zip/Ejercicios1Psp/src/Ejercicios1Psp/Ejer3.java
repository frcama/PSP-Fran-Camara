package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer3 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int n1 = 0;
		int n2 = 0;
		int suma =0;
		
		suma = n1+n2;
		
		System.out.println("Dime el numero 1");
		n1 = teclado.nextInt();
		
		System.out.println("Dime el numero 2");
		n2 = teclado.nextInt();
		
		System.out.println("El total es: "+ suma);
		
	}

}
