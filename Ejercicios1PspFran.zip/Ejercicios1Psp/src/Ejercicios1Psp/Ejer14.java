package Ejercicios1Psp;

import java.util.Scanner;

public class Ejer14 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		
		double radio =0;
		double diametro;
		double aerea;
		
		
		System.out.println("Dime el radio");
		radio = teclado.nextDouble();
		
		diametro = 2* radio;
		aerea = Math.PI * (radio/2);
		
		System.out.println("El diametro es: " + diametro);
		System.out.println("El aerea es: " + aerea);
		
		
	}

}
