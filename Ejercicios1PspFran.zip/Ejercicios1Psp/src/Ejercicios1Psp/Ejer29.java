package Ejercicios1Psp;

public class Ejer29 {

	public static void main(String[] args) {
		vehiculo vehiculo = new vehiculo ("cohe", "ferrar", "488");
		vehiculo vehiculo2 = new vehiculo ("moto", "bwm", "s1000rr");
		vehiculo vehiculo3 = new vehiculo ("cohe", "lambo", "veneo");
		vehiculo vehiculo4 = new vehiculo ("moto", "kawa", "z1000");
		vehiculo vehiculo5 = new vehiculo ("moto", "ktm", "1290");
		
		System.out.println("Los vehiculos son los siguientes: ");
		vehiculo.info();
		vehiculo2.info();
		vehiculo3.info();
		vehiculo4.info();
		vehiculo5.info();
	}

}
