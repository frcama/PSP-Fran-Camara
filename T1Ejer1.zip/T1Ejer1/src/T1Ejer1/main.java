package T1Ejer1;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class main {

	public static void ejer1(String[] args) {
	
	Scanner teclado = new Scanner(System.in);
		
	System.out.println("Ejercicio1");
	String directorio = teclado.next();
	File archivo = new File(directorio);
	System.out.println("Dime el parametro: " + directorio);

	}
	public static void ejer2(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String directorio;
		String tipo;
		String nombre;
		
		
		System.out.println("Ejercicio2");
		System.out.println("Dime un directorio");
		directorio = teclado.next();
		System.out.println("Dime un tipo");
		tipo = teclado.next();
		System.out.println("Dime un nombre");
		nombre = teclado.next();
		File archivo = new File(directorio);
		System.out.println("Dime el directorio : " + directorio + "Dime el tipo de archivo: " + tipo + "Dime el nombre: " + nombre);

		}
	public static void ejer3(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

        String directorio;
        String nombre;
        boolean existe;

        System.out.println("Introduce el directorio");
        directorio = teclado.nextLine();
        System.out.println("Introduce el nombre sin la ruta");
        nombre = teclado.nextLine();

        File direc = new File(directorio);

        System.out.println("¿El directorio existe?");
        System.out.println(nombre + " " + direc.exists());

        if (direc.exists() == true) {
            System.out.println("¿Se puede leer?");
            System.out.println(nombre + " " + direc.canRead());
            System.out.println("¿Se puede editar?");
            System.out.println(nombre + " " + direc.canWrite());
            System.out.println("¿Se puede ejecutar?");
            System.out.println(nombre + " " + direc.canExecute());

        }
		

		}
	public static void ejer4(String[] args) {

		 Scanner teclado = new Scanner(System.in);

		         String directorio;

		         System.out.println("Introduce el directorio");
		         directorio = teclado.nextLine();


		         File direc = new File(directorio);

		         if (direc.exists() == true) {
		             System.out.println("¡El directorio existe! :D");
		         } else if (direc.exists() == false) {
		             System.out.println("ERROR: El directorio NO existe");
		         }
		     }
	public static void ejer5(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String directorio;
		String extension;
		
		System.out.println("Ejercicio5");
		System.out.println("Dime un directorio");
		directorio = teclado.next();
		System.out.println("Dime un extension");
		extension = teclado.next();
		File archivo = new File(directorio);
		
		Filtro Filtro = new Filtro(extension);
		
		File[] ficherosFiltro = archivo.listFiles();		
		
		for (File filtros2 : ficherosFiltro) {
			if(Filtro.accept(filtros2)){
				System.out.println(filtros2.getName());
			}
		}
		
		}
	public static void ejer6(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String directorio;
		
		System.out.println("Ejercicio6");
		System.out.println("Dime un directorio");
		directorio = teclado.next();
		
		File archivo = new File(directorio);
		
		
		
		File[] ficherosFiltro = archivo.listFiles();		
		
		for (File filtros2 : ficherosFiltro) {
				System.out.println(filtros2.getName());
			
		}
		
		}
	public static void ejer7(String [] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int numero;
		String directorio;
		String extension;
		int finaliza;
		
		System.out.println("Ejercicio7");
		System.out.println("Dime un directorio");
		directorio = teclado.next();
		
		ArrayList<Filtro> filtros = new ArrayList<>();
		
		do {
			System.out.println("Dime un extension");
			extension = teclado.next();
			filtros.add(new Filtro(extension));
			System.out.println("1 Extension si 2 finalizar");
			finaliza = teclado.nextInt();
			
		}while(finaliza == 1);
		
		File archivo = new File(directorio);
		
		File[] ficherosFiltro = archivo.listFiles();	
		
		Filtro Filtro = new Filtro(extension);
		for (File filtros2 : ficherosFiltro) {
			if(Filtro.accept(filtros2)){
				System.out.println(filtros2.getName());
			}
		}
		
		}
	public static void ejer8(String [] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String directorio;
		String extension;
		
		
		
		}
	
	
	

}
