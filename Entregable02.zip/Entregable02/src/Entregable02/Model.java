package Entregable02;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Model {
    
    public String text;
    
    public String cargarArchivo(String rutaFitxer) throws IOException {
        text = new String(Files.readAllBytes(Paths.get(rutaFitxer)));
        return text;
    }
   
 
    
    public int buscarPalabra(String paraula) {
        if (text == null || paraula == null || paraula.isEmpty()) {
            return 0;
        }
        String[] paraules = text.split("\\s+");
        int count = 0;
        for (String p : paraules) {
            if (p.equalsIgnoreCase(paraula)) {
                count++;
            }
        }
        return count;
    }
}






