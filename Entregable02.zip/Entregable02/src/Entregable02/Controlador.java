package Entregable02;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JOptionPane;

public class Controlador {

	
	    private Model modelo;
	    private Vista vista;
	    private String Original = "AE02_T1_2_Streams_Groucho.txt";
	    private String Modificado = "AE02_T1_2_Streams_GrouchoRempl.txt";

	    public Controlador(Model modelo, Vista vista) {
	        this.modelo = modelo;
	        this.vista = vista;

	        try {
	            String texto = modelo.cargarArchivo(Original);
	            vista.getTextAreaOriginal().setText(texto);
	        } catch (IOException e) {
	            JOptionPane.showMessageDialog(vista.getTextAreaOriginal(), "Error al cargar el archivo");
	        }

	        

	        
        vista.getBtnBuscar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabraBuscar = vista.getTextFieldBuscar().getText();
                int contador = modelo.buscarPalabra(palabraBuscar);
                JOptionPane.showMessageDialog(vista.getTextAreaOriginal(), 
                	    "La palabra \"" + palabraBuscar + "\" aparece " + contador + " veces.");
            }
        });
}
	    
}
