package Entregable02;

public class Principal {

	public static void main(String[] args) {
		
		Vista vista = new Vista();
		Model modelo = new Model();
		Controlador controlador = new Controlador(modelo, vista);

		
		
		
	}

}
